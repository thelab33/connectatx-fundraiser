from __future__ import annotations
import uuid
from typing import Any, Dict
from sqlalchemy.dialects.postgresql import JSONB
from app.extensions import db
from .mixins import TimestampMixin, SoftDeleteMixin

TEAM_CONFIG_DEFAULT: Dict[str, Any] = {
    "slug": "connect-atx-elite",
    "team_name": "Connect ATX Elite",
    "meta_description": "Connect ATX Elite is a community-powered, non-profit 12U AAU basketball program based in Austin, TX.",
    "lang_code": "en",
    "theme": "dark",
    "theme_color": "#fbbf24",
    "body_class": "",
    "og_title": "Connect ATX Elite",
    "og_description": "Developing skilled athletes and strong leaders on and off the court.",
    "og_image": "images/logo.webp",
    "favicon": "images/favicon.ico",
    "apple_icon": "images/apple-touch-icon.png",
    "hero_image": "images/hero.jpg",
    "custom_css": None,
    "record": {
        "regional": {"wins": 15, "losses": 3},
        "national": {"wins": 17, "losses": 4},
    },
    "impact_stats": [
        {"label": "Players Enrolled", "value": 16},
        {"label": "Honor Roll Scholars", "value": 11},
        {"label": "Tournaments Played", "value": 12},
        {"label": "Years Running", "value": 3},
    ],
}

class Team(db.Model, TimestampMixin, SoftDeleteMixin):
    """Brand and theme configuration for a team, plus roster & stats."""

    __tablename__ = "teams"

    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(
        db.String(36), unique=True, nullable=False,
        default=lambda: str(uuid.uuid4()), index=True
    )
    slug = db.Column(db.String(80), unique=True, nullable=False, index=True)
    team_name = db.Column(db.String(120), nullable=False)
    meta_description = db.Column(db.String(255))
    lang_code = db.Column(db.String(5), nullable=False, default="en")

    # Theming
    theme = db.Column(db.String(30))
    theme_color = db.Column(db.String(7))
    body_class = db.Column(db.String(255))

    # SEO & Social
    og_title = db.Column(db.String(120))
    og_description = db.Column(db.String(255))
    og_image = db.Column(db.String(255))
    favicon = db.Column(db.String(255))
    apple_icon = db.Column(db.String(255))

    # Hero / page defaults
    hero_image = db.Column(db.String(255))
    custom_css = db.Column(db.String(255))

    # Record & impact stats
    record = db.Column(
        JSONB().with_variant(db.JSON, "sqlite"),
        nullable=False,
        default=lambda: TEAM_CONFIG_DEFAULT["record"],
    )
    impact_stats = db.Column(
        JSONB().with_variant(db.JSON, "sqlite"),
        nullable=True,
        default=lambda: TEAM_CONFIG_DEFAULT["impact_stats"],
    )

    # Relationship to players
    players = db.relationship(
        "Player",
        back_populates="team",
        cascade="all, delete-orphan",
        lazy="dynamic",
    )

    # ───────────────────────────────
    def as_dict(self) -> dict:
        return {
            "slug": self.slug,
            "team_name": self.team_name,
            "meta_description": self.meta_description,
            "lang_code": self.lang_code,
            "theme": self.theme,
            "theme_color": self.theme_color,
            "body_class": self.body_class,
            "og_title": self.og_title,
            "og_description": self.og_description,
            "og_image": self.og_image,
            "favicon": self.favicon,
            "apple_icon": self.apple_icon,
            "hero_image": self.hero_image,
            "custom_css": self.custom_css,
            "record": self.record,
            "impact_stats": self.impact_stats,
            "players": [p.as_dict() for p in self.players],
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def get_or_create_default(cls) -> "Team":
        team = cls.query.first()
        if not team:
            team = cls(**TEAM_CONFIG_DEFAULT)
            db.session.add(team)
            db.session.commit()
        return team

    def add_player(self, name: str, role: str = None, photo_url: str = None):
        from .player import Player
        player = Player(name=name, role=role, photo_url=photo_url, team=self)
        db.session.add(player)
        return player

    def __repr__(self) -> str:
        return f"<Team {self.slug} ({self.team_name})>"

