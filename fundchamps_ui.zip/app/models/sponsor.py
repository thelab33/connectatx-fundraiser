"""
Sponsor model — represents a sponsor/donor for campaigns or teams.
"""

from app.extensions import db
from .mixins import TimestampMixin, SoftDeleteMixin


class Sponsor(db.Model, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "sponsors"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, index=True)

    # Financials (stored in cents for Stripe/payments compatibility)
    amount = db.Column(
        db.Integer,
        default=0,
        nullable=False,
        doc="Donation amount in cents",
    )

    status = db.Column(
        db.String(32),
        default="pending",
        nullable=False,
        doc="Donation/payment status",
    )

    def __repr__(self) -> str:
        return f"<Sponsor {self.name} (${self.amount / 100:.2f}) [{self.status}]>"

