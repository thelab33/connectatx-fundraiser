"""
CampaignGoal Model
──────────────────────────────────────────────
Represents a fundraising target for a team, club, or season.

💰 All monetary values are stored in **cents** for Stripe/payments compatibility.
✅ Provides dollar conversions and percentage progress helpers.
⚡ Designed to be Alembic-friendly and safe with missing data.
"""

from __future__ import annotations
import uuid
from typing import Any, Dict
from app.extensions import db
from .mixins import TimestampMixin, SoftDeleteMixin


class CampaignGoal(db.Model, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "campaign_goals"

    # ─── Primary Keys ───────────────────────────────────────────
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(
        db.String(36),
        unique=True,
        nullable=False,
        default=lambda: str(uuid.uuid4()),
        index=True,
        doc="Publicly-safe unique identifier",
    )

    # ─── Financial Targets ──────────────────────────────────────
    goal_amount = db.Column(
        db.Integer,
        nullable=False,
        default=0,
        doc="Target fundraising goal, in cents",
    )
    total = db.Column(
        db.Integer,
        nullable=False,
        default=0,
        doc="Amount raised so far, in cents",
    )

    # ─── Status ─────────────────────────────────────────────────
    active = db.Column(
        db.Boolean,
        nullable=False,
        default=True,
        index=True,
        doc="Is this goal currently live?",
    )

    # ─── Computed Properties ────────────────────────────────────
    @property
    def goal_dollars(self) -> float:
        """Return the goal in dollars."""
        return round((self.goal_amount or 0) / 100.0, 2)

    @property
    def raised_dollars(self) -> float:
        """Return the amount raised in dollars."""
        return round((self.total or 0) / 100.0, 2)

    @property
    def percent_raised(self) -> float:
        """Return % progress toward goal as a float (0–100)."""
        try:
            if self.goal_amount > 0:
                return round((self.total / self.goal_amount) * 100, 1)
        except ZeroDivisionError:
            pass
        return 0.0

    def percent_complete(self) -> int:
        """Return % progress as a rounded int (for progress bars)."""
        return int(self.percent_raised)

    # ─── Serialization ──────────────────────────────────────────
    def as_dict(self) -> Dict[str, Any]:
        """Serialize goal data for JSON APIs or template rendering."""
        return {
            "uuid": self.uuid,
            "goal_amount_cents": self.goal_amount,
            "total_raised_cents": self.total,
            "goal_dollars": self.goal_dollars,
            "raised_dollars": self.raised_dollars,
            "percent_raised": self.percent_raised,
            "percent_complete": self.percent_complete(),
            "active": self.active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    # ─── Representation ─────────────────────────────────────────
    def __repr__(self) -> str:
        status = "ACTIVE" if self.active else "INACTIVE"
        return (
            f"<CampaignGoal {self.uuid} "
            f"Goal=${self.goal_dollars:,.2f} "
            f"Raised=${self.raised_dollars:,.2f} "
            f"({self.percent_raised}% – {status})>"
        )

