# app/models/donation.py
from datetime import datetime
from app.extensions import db

class Donation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False)
    email = db.Column(db.String(160), nullable=False, index=True)
    tier = db.Column(db.String(40), nullable=True)
    amount_cents = db.Column(db.Integer, nullable=False)  # store cents
    logo_path = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

