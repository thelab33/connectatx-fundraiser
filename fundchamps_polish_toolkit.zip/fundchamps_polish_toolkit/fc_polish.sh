#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-./templates}"
BRAND="${FC_BRAND_NAME:-FundChamps}"
PRIMARY="${FC_PRIMARY:-#facc15}"
SECONDARY="${FC_SECONDARY:-#0ea5e9}"
RADIUS="${FC_RADIUS:-14}"
SHADOW="${FC_SHADOW:-0 10px 30px rgba(0,0,0,.25)}"
ASSETS="${FC_ASSETS_DIR:-./static}"
STATIC_URL="${FC_STATIC_URL:-/static}"

# venv bootstrap
if [ ! -d ".fc-polish-venv" ]; then
  python3 -m venv .fc-polish-venv
fi
source .fc-polish-venv/bin/activate
pip install --upgrade pip >/dev/null
pip install beautifulsoup4 lxml pillow >/dev/null

python3 "$(dirname "$0")/fc_polish.py" \
  --root "$ROOT" --write \
  --brand-name "$BRAND" \
  --primary "$PRIMARY" \
  --secondary "$SECONDARY" \
  --radius "$RADIUS" \
  --shadow "$SHADOW" \
  --assets-dir "$ASSETS" \
  --static-url "$STATIC_URL"

echo "✅ FundChamps polish completed for $ROOT"
