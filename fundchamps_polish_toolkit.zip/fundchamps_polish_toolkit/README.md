# FundChamps UI/UX Refinement — Auto Polish Toolkit

This toolkit standardizes your FundChamps fundraising/sponsorship UI across partials:
- **Typography**: applies `fc-h1..fc-h6` classes consistently.
- **Brand tokens**: generates `fc_tokens.css` with accent palette, radius, shadow.
- **Assets**: converts local images to **WebP/AVIF** and wraps `<img>` in `<picture>`.
- **Consistency**: normalizes buttons with `.fc-btn` (radius/shadow).
- **A11y**: adds missing `alt=""`, completes `role="meter"` ARIA attrs, flags low-contrast inline styles.
- **Reports**: JSON + Markdown in `./fc_polish_reports`.

> Safe on Jinja: we mask `{% ... %}`, `{{ ... }}`, `{# ... #}` before parsing and restore after edits.

## Quick start

```bash
# unzip and cd
chmod +x fc_polish.sh
./fc_polish.sh ./templates
```

Environment overrides:

```bash
export FC_BRAND_NAME="FundChamps"
export FC_PRIMARY="#facc15"
export FC_SECONDARY="#0ea5e9"
export FC_RADIUS=14
export FC_SHADOW="0 10px 30px rgba(0,0,0,.25)"
export FC_ASSETS_DIR="./static"
export FC_STATIC_URL="/static"
./fc_polish.sh ./templates
```

Or run the Python directly:

```bash
python3 fc_polish.py --root ./templates --write \
  --brand-name "FundChamps" --primary "#facc15" --secondary "#0ea5e9" \
  --radius 14 --shadow "0 10px 30px rgba(0,0,0,.25)" \
  --assets-dir ./static --static-url /static
```

## What it changes

- Adds `.fc-h1..fc-h6` to headings; generates `fc_tokens.css` with the scale.
- Appends `.fc-btn` to any element already using `.btn` for consistent radius/shadow.
- Ensures `<img>` have `alt` (empty if unknown) and wraps local images in `<picture>` with AVIF/WebP siblings (requires Pillow).
- Completes ARIA on `[role="meter"]` (valuemin/max/now) when needed.
- Flags any **inline** color vs background hex pairs that fail WCAG AA (ratio < 4.5).

## Non-destructive

- Dry-run is default in `fc_polish.py`. The wrapper uses `--write` and creates `.bak` backups.
- Output reports in `./fc_polish_reports/report.json` and `report.md`.

## Notes

- AVIF requires Pillow built with AVIF support. If not available, the tool still creates WebP and the AVIF `<source>` will be skipped.
- We intentionally do **not** try to rewrite CSS files; we focus on safe HTML-level fixes and variables.
- For site-wide tokens, import `fc_tokens.css` in your base layout `<head>` (or inline it).

MIT © FundChamps
