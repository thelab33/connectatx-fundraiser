#!/usr/bin/env python3
"""
FundChamps UI/UX Refinement — Auto Polish Tool
----------------------------------------------
Run this against your templates/partials to standardize branding, polish visuals,
tighten a11y, and optimize assets (WebP/AVIF + <picture>).

Usage:
  python fc_polish.py --root ./templates --write \
      --brand-name "FundChamps" --primary "#facc15" --secondary "#0ea5e9" \
      --radius 14 --shadow "0 10px 30px rgba(0,0,0,.25)" \
      --assets-dir ./static --static-url /static

Notes:
- Safe on Jinja: we *mask* Jinja blocks before HTML parsing and restore after edits.
- Dry-run by default. Use --write to modify files (with .bak backups).
- Generates a JSON + Markdown report in ./fc_polish_reports
- Dependencies: bs4, lxml (optional), Pillow
"""

import argparse, sys, re, io, json, hashlib
from pathlib import Path
from typing import Tuple, Dict, List
from dataclasses import dataclass, field

# Best-effort: avoid import errors if lxml is missing
try:
    from bs4 import BeautifulSoup
    BS_PARSER = "lxml"
except Exception:
    from bs4 import BeautifulSoup
    BS_PARSER = "html.parser"

try:
    from PIL import Image
    PIL_OK = True
except Exception:
    PIL_OK = False

# ----------------------------- CLI & Config -----------------------------

@dataclass
class FCConfig:
    brand_name: str = "FundChamps"
    primary: str = "#facc15"
    secondary: str = "#0ea5e9"
    radius: int = 14
    shadow: str = "0 10px 30px rgba(0,0,0,.25)"
    assets_dir: Path = Path("./static")
    static_url: str = "/static"
    write: bool = False

@dataclass
class FileReport:
    path: str
    changed: bool = False
    issues: List[str] = field(default_factory=list)
    fixes: List[str] = field(default_factory=list)
    images_converted: List[str] = field(default_factory=list)
    headings_normalized: int = 0
    alt_added: int = 0
    aria_added: int = 0
    btn_normalized: int = 0
    picture_wrapped: int = 0
    contrast_flags: int = 0

# ----------------------------- Utilities -----------------------------

JINJA_RE = re.compile(r"({%.*?%}|{{.*?}}|{#.*?#})", re.DOTALL)

def mask_jinja(text: str) -> Tuple[str, Dict[str, str]]:
    """Replace Jinja chunks with tokens; return masked text and map."""
    mapping = {}
    def repl(m):
        token = f"@@JINJA_{hashlib.sha1(m.group(0).encode()).hexdigest()[:16]}@@"
        mapping[token] = m.group(0)
        return token
    return JINJA_RE.sub(repl, text), mapping

def unmask_jinja(text: str, mapping: Dict[str, str]) -> str:
    for token, block in mapping.items():
        text = text.replace(token, block)
    return text

def ensure_css_tokens(css_path: Path, cfg: FCConfig):
    css_path.parent.mkdir(parents=True, exist_ok=True)
    if not css_path.exists():
        css_path.write_text(f""":root {{
  --accent: {cfg.primary};
  --accent-2: {cfg.secondary};
  --radius: {cfg.radius}px;
  --shadow: {cfg.shadow};
  --panel-border: hsla(0,0%,100%,.10);
  --text: #e6e8ee;
  --text-sub: #aab0bb;
}}
/* Typography scale */
.fc-h1{{font-size:clamp(2rem,1.2rem + 3vw,3.2rem);font-weight:1000;line-height:1.04}}
.fc-h2{{font-size:clamp(1.6rem,1rem + 2vw,2.4rem);font-weight:900;line-height:1.06}}
.fc-h3{{font-size:clamp(1.25rem,.9rem + 1.5vw,1.8rem);font-weight:900;line-height:1.08}}
.fc-body{{font-size:1rem;line-height:1.6}}
.fc-cap{{font-size:.875rem;opacity:.85}}
/* Components */
.fc-btn{border-radius:999px;box-shadow:var(--shadow)}
.fc-card{border-radius:var(--radius);box-shadow:var(--shadow)}
.fc-badge{border-radius:8px;border:1px solid var(--panel-border)}
""", encoding="utf-8")

# WCAG contrast helpers
def hex_to_rgb(h: str):
    h = h.strip()
    if h.startswith("#"):
        h = h[1:]
    if len(h) == 3:
        h = "".join([c*2 for c in h])
    try:
        return tuple(int(h[i:i+2], 16)/255 for i in (0,2,4))
    except Exception:
        return None

def rel_luminance(rgb):
    def f(c):
        return c/12.92 if c <= 0.03928 else ((c+0.055)/1.055)**2.4
    r,g,b = rgb
    return 0.2126*f(r) + 0.7152*f(g) + 0.0722*f(b)

def contrast_ratio(fg, bg):
    L1, L2 = rel_luminance(fg), rel_luminance(bg)
    lighter, darker = max(L1, L2), min(L1, L2)
    return (lighter + 0.05) / (darker + 0.05)

HEX_COL_RE = re.compile(r"#(?:[0-9a-fA-F]{3}){1,2}")

def check_inline_contrast(style_value:str, report:FileReport):
    # extremely simple: if both color and background-color are explicit hex
    color_m = re.search(r"color\s*:\s*(#[0-9a-fA-F]{3,6})", style_value or "")
    bg_m = re.search(r"background(?:-color)?\s*:\s*(#[0-9a-fA-F]{3,6})", style_value or "")
    if color_m and bg_m:
        fg = hex_to_rgb(color_m.group(1)); bg = hex_to_rgb(bg_m.group(1))
        if fg and bg:
            cr = contrast_ratio(fg, bg)
            if cr < 4.5:
                report.issues.append(f"Low contrast inline style (ratio {cr:.2f} < 4.5)")
                report.contrast_flags += 1

# ----------------------------- HTML transforms -----------------------------

HEADING_TAGS = ["h1","h2","h3","h4","h5","h6"]

def normalize_headings(soup, report:FileReport):
    count = 0
    for tag in soup.find_all(HEADING_TAGS):
        cls = tag.get("class", [])
        target = f"fc-h{tag.name[-1]}"
        if target not in cls:
            cls.append(target); tag["class"] = cls; count += 1
    report.headings_normalized += count
    if count:
        report.fixes.append(f"Applied {count} heading classes (fc-h1..fc-h6).")

def unify_buttons(soup, report:FileReport):
    count = 0
    for tag in soup.find_all(["a","button"]):
        classes = tag.get("class", [])
        if "btn" in classes and "fc-btn" not in classes:
            classes.append("fc-btn"); tag["class"] = classes; count += 1
        # icon-only buttons need aria-label
        if tag.name == "button" and not tag.text.strip():
            if not tag.get("aria-label"):
                tag["aria-label"] = "Button"
                report.issues.append("Icon-only button missing aria-label → added 'Button'.")
                report.aria_added += 1
    if count:
        report.btn_normalized += count
        report.fixes.append(f"Normalized {count} buttons (radius/shadow via .fc-btn).")

def ensure_alt_and_roles(soup, report:FileReport):
    adds = 0; arias = 0
    for img in soup.find_all("img"):
        if img.get("alt") is None:
            img["alt"] = ""
            adds += 1
    for meter in soup.select("[role='meter']"):
        if not meter.get("aria-valuemin"): meter["aria-valuemin"]="0"; arias+=1
        if not meter.get("aria-valuemax"): meter["aria-valuemax"]="100"; arias+=1
        if not meter.get("aria-valuenow"):
            # guess from --p in style
            style = meter.get("style","")
            m = re.search(r"--p:\s*([0-9.]+)%", style)
            if m:
                meter["aria-valuenow"]=m.group(1)
                arias+=1
    report.alt_added += adds
    report.aria_added += arias
    if adds: report.fixes.append(f"Added alt to {adds} <img> elements.")
    if arias: report.fixes.append(f"Completed {arias} missing ARIA meter attributes.")

def pictureify_images(soup, report:FileReport, file_dir:Path, cfg:FCConfig):
    """
    Wrap plain <img> in <picture> with avif/webp sources when local assets.
    Convert assets under cfg.assets_dir to webp/avif (if PIL available).
    """
    if not PIL_OK:
        return
    converted = 0; wrapped = 0
    for img in list(soup.find_all("img")):
        src = img.get("src") or ""
        if not src or "://" in src: # skip remote
            continue
        # resolve path under assets_dir if it lives there
        # tolerate leading static_url
        rel = src
        if cfg.static_url and src.startswith(cfg.static_url):
            rel = src[len(cfg.static_url):].lstrip("/")
        img_path = cfg.assets_dir / rel
        if not img_path.exists():
            continue

        # Convert to webp/avif siblings
        stem = img_path.with_suffix("").name
        base = img_path.with_suffix("")
        out_webp = img_path.with_suffix(".webp")
        out_avif = img_path.with_suffix(".avif")
        try:
            with Image.open(img_path) as im:
                # Save webp (lossless for png, quality 82 otherwise)
                if not out_webp.exists():
                    params = {"quality": 82}
                    if im.format == "PNG":
                        params = {"lossless": True}
                    im.save(out_webp, "WEBP", **params)
                    converted += 1
                # Try AVIF (may fail if codec missing)
                if not out_avif.exists():
                    try:
                        im.save(out_avif, "AVIF", quality=50)
                        converted += 1
                    except Exception:
                        pass
        except Exception:
            continue

        # Build <picture>
        picture = soup.new_tag("picture")
        # AVIF first
        if out_avif.exists():
            srcset = f"{cfg.static_url.rstrip('/')}/{(cfg.assets_dir/rel).with_suffix('.avif').relative_to(cfg.assets_dir)}"
            avif = soup.new_tag("source")
            avif["type"] = "image/avif"
            avif["srcset"] = srcset
            picture.append(avif)
        # WebP
        if out_webp.exists():
            srcset = f"{cfg.static_url.rstrip('/')}/{(cfg.assets_dir/rel).with_suffix('.webp').relative_to(cfg.assets_dir)}"
            webp = soup.new_tag("source")
            webp["type"] = "image/webp"
            webp["srcset"] = srcset
            picture.append(webp)

        # Move original <img> inside
        picture.append(img.extract())
        img.replace_with(picture)
        wrapped += 1

    report.images_converted += [str(converted)]
    report.picture_wrapped += wrapped
    if converted: report.fixes.append(f"Converted {converted} images to WebP/AVIF.")
    if wrapped: report.fixes.append(f"Wrapped {wrapped} <img> with <picture>.")

def scan_inline_contrast(soup, report:FileReport):
    for el in soup.find_all(True):
        style = el.get("style")
        if style:
            check_inline_contrast(style, report)

# ----------------------------- Runner -----------------------------

def process_file(path:Path, cfg:FCConfig) -> FileReport:
    report = FileReport(path=str(path))
    text = path.read_text(encoding="utf-8", errors="ignore")
    masked, mapping = mask_jinja(text)

    # Parse
    soup = BeautifulSoup(masked, BS_PARSER)

    # Transforms
    normalize_headings(soup, report)
    unify_buttons(soup, report)
    ensure_alt_and_roles(soup, report)
    pictureify_images(soup, report, path.parent, cfg)
    scan_inline_contrast(soup, report)

    output = unmask_jinja(str(soup), mapping)

    # Strip BeautifulSoup added <html><body> wrappers for partials
    output = output.replace("<html><body>", "").replace("</body></html>", "")

    changed = (output != text)
    report.changed = changed
    return report, (output if changed else text)

def write_report(reports_dir:Path, reports:List[FileReport]):
    reports_dir.mkdir(parents=True, exist_ok=True)
    data = [r.__dict__ for r in reports]
    (reports_dir/"report.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    # Pretty markdown
    lines = ["# FundChamps Auto-Polish Report\n"]
    for r in reports:
        lines.append(f"## {r.path}")
        lines.append(f"- changed: **{r.changed}**")
        if r.fixes: lines.append(f"- fixes: " + "; ".join(r.fixes))
        if r.issues: lines.append(f"- issues: " + "; ".join(r.issues))
        lines.append("")
    (reports_dir/"report.md").write_text("\n".join(lines), encoding="utf-8")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True, help="Root folder containing templates/partials")
    ap.add_argument("--write", action="store_true", help="Write changes in place (creates .bak backups)")
    ap.add_argument("--brand-name", default="FundChamps")
    ap.add_argument("--primary", default="#facc15")
    ap.add_argument("--secondary", default="#0ea5e9")
    ap.add_argument("--radius", type=int, default=14)
    ap.add_argument("--shadow", default="0 10px 30px rgba(0,0,0,.25)")
    ap.add_argument("--assets-dir", type=Path, default=Path("./static"))
    ap.add_argument("--static-url", default="/static")
    args = ap.parse_args()

    cfg = FCConfig(
        brand_name=args.brand_name,
        primary=args.primary,
        secondary=args.secondary,
        radius=args.radius,
        shadow=args.shadow,
        assets_dir=args.assets_dir,
        static_url=args.static_url,
        write=args.write,
    )

    # token css
    ensure_css_tokens(Path("fc_tokens.css"), cfg)

    # discover files
    patterns = (".html",".htm",".jinja",".jinja2",".tpl",".njk")
    files = [p for p in args.root.rglob("*") if p.suffix.lower() in patterns]
    if not files:
        print("No template files found under", args.root, file=sys.stderr)
        sys.exit(2)

    reports = []
    for p in files:
        rep, out = process_file(p, cfg)
        reports.append(rep)
        if cfg.write and rep.changed:
            bak = p.with_suffix(p.suffix + ".bak")
            if not bak.exists():
                bak.write_text(p.read_text(encoding="utf-8", errors="ignore"), encoding="utf-8")
            p.write_text(out, encoding="utf-8")

    write_report(Path("./fc_polish_reports"), reports)
    print(f"Processed {len(files)} files. Changed: {sum(1 for r in reports if r.changed)}. Reports in ./fc_polish_reports")

if __name__ == "__main__":
    main()
