bind = "0.0.0.0:8000"
workers = 3
worker_class = "gthread"
threads = 8
timeout = 60
accesslog = "-"
errorlog = "-"

