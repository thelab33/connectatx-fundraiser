README_APPLY.md

This bundle contains files prepared by the repo owner to share with a maintainer.
Contents:
 - payload/...   (files to be applied relative to repo root)
 - MANIFEST.txt  (list of files)
 - metadata.json (git metadata if available)
 - README_APPLY.md (this file)

Inspect everything before applying. The maintainer should backup before writing.
