<script type="module" src="{{ url_for('static', filename='js/extracted/partials__footer.html__1.js', v='1.0.0') }}"></script>

