# FundChamps • Starforge Patch v1

**Built:** 2025-08-31T03:55:09.614332Z

This patch ships the *Starforge UI/UX Elite Enhancement v3* bundle + a tiny JS addon with **10 elite one-liners** for fundraising/sponsorship UX.

## Install

1. **Copy files** into your project:
```
/templates/bundles/fundchamps_starforge_ui_ux_elite_enhancement_v3.html
/templates/partials/starforge_patch_include.html
/static/js/starforge_elite_addons.min.js
```

2. **Load the bundle** in your page template:
```jinja
{% raw %}{% import "bundles/fundchamps_starforge_ui_ux_elite_enhancement_v3.html" as fc_elite %}
{{ fc_elite.render({
  'hero': true,
  'tiers': SHOW_TIERS,
  'impact': SHOW_IMPACT,
  'about': SHOW_ABOUT,
  'newsletter': true,
  'donation_modal': true
}) }}{% endraw %}
```

3. **Include the addons loader** (ideally in a `body_scripts` block):
```jinja
{% raw %}{% include "partials/starforge_patch_include.html" %}{% endraw %}
```

## The 10 one-liners

1. UTM persistence across `/donate` + Stripe links.  
2. Deep-link tier preselect via `?tier=Gold`.  
3. Save last clicked tier/amount (intent memory).  
4. Smooth-scroll for `#tiers` anchor jumps.  
5. ARIA urgency announcement when ≤2 spots left.  
6. Apple Pay availability flag (`.fc-apple-pay` on `<html>`).  
7. `+` key bumps custom donate amount by $25.  
8. Localized tooltip for `[data-urgency-deadline]`.  
9. Push `donation_success` event to `dataLayer`.  
10. Harden Stripe/PayPal links (`target=_blank`, `rel="noopener"`, add UTM).

All lines are idempotent and safe to ship in production.
