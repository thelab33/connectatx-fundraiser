const C = "elite-v1";
const AS = ["/", "/stats", "/static/css/elite-upgrades.css"];
self.addEventListener("install", (e) => {
  e.waitUntil(
    caches
      .open(C)
      .then((c) => c.addAll(AS))
      .then(() => self.skipWaiting()),
  );
});
self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches
      .keys()
      .then((k) =>
        Promise.all(k.filter((x) => x !== C).map((x) => caches.delete(x))),
      )
      .then(() => self.clients.claim()),
  );
});
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  const r = caches.match(e.request).then(
    (m) =>
      m ||
      fetch(e.request)
        .then((res) => {
          caches.open(C).then((c) => c.put(e.request, res.clone()));
          return res;
        })
        .catch(() => m),
  );
  e.respondWith(r);
});
