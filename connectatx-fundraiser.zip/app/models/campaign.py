# app/models/campaign.py
"""Legacy placeholder to satisfy the auto-loader; no active models here."""
from __future__ import annotations

__all__: list[str] = []

