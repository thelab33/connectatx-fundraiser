Add these to your root layout (head/body):
<link rel="stylesheet" href="/ux/elite.css">
<script type="module" src="/ux/init.js" defer></script>
Optional: set brand color on <html data-brand="#FFD147"> and add [data-toggle-theme] to any button for Light/Dark toggle.
