module.exports = {
  plugins: [
    "stylelint-declaration-block-no-ignored-properties",
    // other plugins...
  ],
  rules: {
    "plugin/declaration-block-no-ignored-properties": true,
    // other rules...
  },
};
