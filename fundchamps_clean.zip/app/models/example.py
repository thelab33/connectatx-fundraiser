# Temporary stub so imports don't fail during launch
class Example:
    id = 1
    name = "Placeholder Example"

    def __repr__(self):
        return f"<Example {self.id}: {self.name}>"
