# FundChamps • Elite Header Widget (Inline) — v3.1

Drop-in partial with inline CSS/JS (nonce-ready). Include:
```jinja2
{% include 'partials/_header_pro.html' %}
```
Provide optional vars: team, funds_raised, fundraising_goal, end_date (ISO), stripe_payment_link/HREF_DONATE, ticker_items.
