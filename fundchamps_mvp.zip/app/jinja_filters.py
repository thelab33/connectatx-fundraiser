def register_jinja_filters(app):
    # TODO: restore actual filters from last good repo
    # Temporary no-op so app can start
    pass
