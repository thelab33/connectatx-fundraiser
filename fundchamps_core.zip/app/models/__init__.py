"""
Autoload all models and mixins for Starforge SaaS.

Benefits:
- Centralized imports for easy access:
    from app.models import Team, Player, Sponsor
- Ensures Alembic autogeneration sees all models without scattered imports
- Handles optional/experimental models gracefully with logging
"""

from __future__ import annotations
import logging
from app.extensions import db  # Expose db for all mixins/models

logger = logging.getLogger(__name__)

# ─── Mixins ─────────────────────────────────────────────────────
from .mixins import TimestampMixin, SoftDeleteMixin

# ─── Core Models ────────────────────────────────────────────────
from .campaign_goal import CampaignGoal
from .player import Player
from .sponsor import Sponsor
from .team import Team
from .transaction import Transaction

# Optional models: only import if present
OPTIONAL_MODELS = [
    ("example", "Example"),
    ("sms_log", "SMSLog"),
    ("user", "User"),
]

for module_name, class_name in OPTIONAL_MODELS:
    try:
        module = __import__(f"app.models.{module_name}", fromlist=[class_name])
        globals()[class_name] = getattr(module, class_name)
        logger.debug(f"✅ Loaded optional model: {class_name} from {module_name}")
    except (ImportError, AttributeError) as e:
        logger.warning(f"⚠️ Optional model {class_name} not loaded: {e}")

# ─── Public API ─────────────────────────────────────────────────
__all__ = [
    "db",
    "TimestampMixin",
    "SoftDeleteMixin",
    "CampaignGoal",
    "Player",
    "Sponsor",
    "Team",
    "Transaction",
    # Optional models will be injected dynamically if present
    *[cls for _, cls in OPTIONAL_MODELS if cls in globals()],
]

