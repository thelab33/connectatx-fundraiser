from __future__ import annotations

import logging
import os
import time
from datetime import datetime, timezone
from importlib import import_module
from pathlib import Path
from typing import Any, Type
from uuid import uuid4

from dotenv import load_dotenv
from flask import Flask, g, jsonify, request, url_for
from werkzeug.exceptions import HTTPException, InternalServerError
from werkzeug.routing import BuildError

# ── Env & Paths ───────────────────────────────────────────────────────────────
load_dotenv()
BASE_DIR = Path(__file__).resolve().parent.parent

# ── Core Extensions (singletons) ──────────────────────────────────────────────
from app.extensions import db, migrate, socketio, mail, csrf, cors, login_manager, babel

# Optional deps
USE_LOGIN = bool(login_manager)
USE_BABEL = bool(babel)
USE_CLI = False
try:
    from app.cli import starforge  # type: ignore
    USE_CLI = True
except Exception:
    starforge = None  # type: ignore

try:
    from flask_compress import Compress  # type: ignore
except Exception:
    Compress = None  # type: ignore

try:
    from flask_talisman import Talisman  # type: ignore
except Exception:
    Talisman = None  # type: ignore

try:
    from flask_wtf.csrf import generate_csrf  # type: ignore
except Exception:
    generate_csrf = None  # type: ignore

# ── Helpers ───────────────────────────────────────────────────────────────────
ConfigLike = str | Type[Any]

def _resolve_config(target: ConfigLike | None) -> ConfigLike:
    """Resolve dotted config path or class."""
    if target is None:
        target = os.getenv("FLASK_CONFIG", "app.config.DevelopmentConfig")
    if isinstance(target, str) and target == "app.config.config.DevelopmentConfig":
        return "app.config.DevelopmentConfig"
    return target

def _json_error(message: str, status: int, **extra: Any):
    return jsonify({"status": "error", "message": message, **extra}), status

def _mtime_or_now(path: Path) -> int:
    try:
        return int(path.stat().st_mtime)
    except Exception:
        return int(datetime.now(timezone.utc).timestamp())

def _configure_logging(app: Flask) -> None:
    if not logging.getLogger().handlers:
        logging.basicConfig(
            level=app.config.get("LOG_LEVEL", "INFO"),
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )
    logging.getLogger("werkzeug").setLevel(app.config.get("WERKZEUG_LOG_LEVEL", "WARNING"))
    app.logger.info("Loaded configuration: %s | DEBUG=%s", app.config.get("ENV", "?"), app.debug)
    app.logger.info("DB: %s", app.config.get("SQLALCHEMY_DATABASE_URI", "<unset>"))

def _parse_cors_origins(env: str) -> str | list[str]:
    """Parse CORS_ORIGINS env as '*' or comma list."""
    default_prod = os.getenv("PRIMARY_ORIGIN", "https://connect-atx-elite.com")
    raw = os.getenv("CORS_ORIGINS", "*" if env != "production" else default_prod)
    if isinstance(raw, str) and raw not in {"*", ""} and "," in raw:
        return [o.strip() for o in raw.split(",") if o.strip()]
    return raw

# ── Blueprint Import & Register ───────────────────────────────────────────────
def _safe_register(app: Flask, dotted: str, attr: str, url_prefix: str | None) -> bool:
    """Import and register a blueprint with clear logging."""
    disable = {p.strip().lower() for p in os.getenv("DISABLE_BPS", "").split(",") if p.strip()}
    key = f"{dotted}:{attr}".lower()

    if dotted.split(".")[-1] in disable or key in disable:
        app.logger.info(f"⏭️  Disabled: {dotted}")
        return False

    try:
        mod = import_module(dotted)
        bp = getattr(mod, attr, None)
    except Exception as e:
        app.logger.warning(f"⚠️  Import failed: {dotted} → {e}")
        return False

    if not bp:
        app.logger.warning(f"⚠️  Missing attr '{attr}' in {dotted}")
        return False

    if bp.name in app.blueprints:
        app.logger.info(f"⏭️  Already registered: {bp.name}")
        return False

    prefix = url_prefix or getattr(bp, "url_prefix", None)
    try:
        app.register_blueprint(bp, url_prefix=prefix)
        app.logger.info(f"🧩 Registered: {bp.name:<20} → {prefix or '/'}")
        return True
    except Exception as exc:
        app.logger.error(f"❌ Failed to register {dotted}: {exc}", exc_info=True)
        return False

# ── App Factory ───────────────────────────────────────────────────────────────
def create_app(config_class: ConfigLike | None = None) -> Flask:
    app = Flask(
        __name__,
        static_folder=str(BASE_DIR / "app/static"),
        template_folder=str(BASE_DIR / "app/templates"),
    )

    # 1) Config
    cfg = _resolve_config(config_class)
    try:
        app.config.from_object(cfg)
    except Exception as exc:
        legacy = "app.config.config.DevelopmentConfig"
        if isinstance(cfg, str) and cfg != legacy:
            try:
                app.config.from_object(legacy)
            except Exception:
                raise RuntimeError(f"❌ Invalid FLASK_CONFIG '{cfg}': {exc}") from exc
        else:
            raise RuntimeError(f"❌ Invalid FLASK_CONFIG '{cfg}': {exc}") from exc

    app.config.setdefault("JSON_SORT_KEYS", False)
    app.config.setdefault("JSONIFY_PRETTYPRINT_REGULAR", False)

    # 2) Logging
    _configure_logging(app)

    # 3) CORS
    cors_origins = _parse_cors_origins(app.config.get("ENV", "development"))
    if cors:
        cors.init_app(
            app,
            supports_credentials=True,
            resources={r"/api/*": {"origins": cors_origins}},
            expose_headers=["X-Request-ID"],
            allow_headers=["Content-Type", "Authorization"],
            methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        )

    # 4) Security Headers
    if app.config.get("ENV") == "production" and Talisman:
        Talisman(app, content_security_policy=None)

    # 5) CSRF
    if csrf:
        csrf.init_app(app)

    # 6) Core Extensions
    db.init_app(app)
    migrate.init_app(app, db)
    socketio.init_app(app, cors_allowed_origins=cors_origins)
    mail.init_app(app)
    if Compress:
        Compress(app)

    # 7) Request Meta
    @app.before_request
    def _req_meta() -> None:
        g.request_id = request.headers.get("X-Request-ID", uuid4().hex)
        g._start_ts = time.perf_counter()

    @app.after_request
    def _std_headers(resp):
        resp.headers.setdefault("X-Request-ID", getattr(g, "request_id", uuid4().hex))
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        try:
            dur_ms = (time.perf_counter() - g._start_ts) * 1000.0
            resp.headers.setdefault("Server-Timing", f"app;dur={dur_ms:.1f}")
        except Exception:
            pass
        return resp

    # 8) Login
    if USE_LOGIN and login_manager:
        login_manager.init_app(app)
        login_manager.login_view = "admin.dashboard"
        try:
            from app.models.user import User  # type: ignore
        except Exception as exc:
            User = None  # type: ignore
            app.logger.warning("Login enabled but User model import failed: %s", exc)

        @login_manager.user_loader
        def load_user(user_id: str):
            return User.query.get(int(user_id)) if User else None

    # 9) I18N
    _t = lambda s: s
    if USE_BABEL and babel:
        babel.init_app(app)  # type: ignore[call-arg]

    # 10) Jinja Context & Filters
    @app.context_processor
    def _base_ctx() -> dict[str, Any]:
        def has_endpoint(name: str) -> bool:
            return name in app.view_functions

        def safe_url_for(endpoint: str, **values: Any) -> str:
            try:
                return url_for(endpoint, **values)
            except (BuildError, Exception):
                return ""

        static_root = Path(app.static_folder or "app/static")
        css = static_root / "css" / "tailwind.min.css"
        js = static_root / "js" / "main.js"
        asset_version = max(_mtime_or_now(css), _mtime_or_now(js))

        return {
            "app_env": app.config.get("ENV"),
            "app_config": app.config,
            "now": lambda: datetime.now(timezone.utc),
            "_": _t,
            "has_endpoint": has_endpoint,
            "safe_url_for": safe_url_for,
            "asset_version": asset_version,
        }

    # 11) Error Handling
    def _wants_json() -> bool:
        accept = (request.headers.get("Accept") or "").lower()
        return "application/json" in accept or request.path.startswith("/api") or request.is_json

    @app.errorhandler(HTTPException)
    def _http_err(err: HTTPException):
        if _wants_json():
            return _json_error(err.description or err.name, err.code or 500, request_id=getattr(g, "request_id", None))
        return err

    @app.errorhandler(Exception)
    def _uncaught(err: Exception):
        app.logger.exception("Unhandled error: %s", err)
        if _wants_json():
            status = err.code if isinstance(err, HTTPException) else 500  # type: ignore[attr-defined]
            return _json_error("Internal Server Error", status, request_id=getattr(g, "request_id", None))
        return InternalServerError()

    # 12) Blueprints (FIX: main_bp instead of bp)
    blueprints = [
        ("app.routes.main",          "main_bp", "/"),
        ("app.routes.api",           "bp",      "/api"),
        ("app.routes.sms",           "bp",      "/sms"),
        ("app.routes.stripe_routes", "bp",      "/stripe"),
        ("app.routes.webhooks",      "bp",      "/webhooks"),
        ("app.admin.routes",         "bp",      "/admin"),
        ("app.routes.donations",     "bp",      "/donations"),
    ]
    for dotted, attr, prefix in blueprints:
        _safe_register(app, dotted, attr, prefix)

    # 13) CLI
    if USE_CLI and starforge:
        app.cli.add_command(starforge)

    # 14) Health & Version
    @app.get("/healthz")
    def _healthz():
        return {"status": "ok", "message": "FundChamps Flask live!", "request_id": getattr(g, "request_id", None)}

    @app.get("/version")
    def _version():
        return {"version": os.getenv("GIT_COMMIT", "dev"), "env": app.config.get("ENV")}

    # 15) CSRF Cookie for AJAX
    if csrf and generate_csrf:
        @app.after_request
        def inject_csrf_cookie(resp):
            try:
                secure = app.config.get("ENV") == "production"
                resp.set_cookie("csrf_token", generate_csrf(), samesite="Lax", secure=secure)
            except Exception:
                pass
            return resp

    # 16) Team Defaults in Context
    @app.context_processor
    def _fc_inject_team_defaults():
        cfg = app.config.get("TEAM_CONFIG", {})
        tn = cfg.get("team_name") or cfg.get("TEAM_NAME") or "Connect ATX Elite"
        tc = cfg.get("theme_color") or cfg.get("THEME_COLOR") or "#facc15"
        class _Obj(dict): __getattr__ = dict.get
        return {"team": _Obj(team_name=tn, theme_color=tc)}

    # 17) Launch Banner
    stripe_ok = bool(os.getenv("STRIPE_SECRET_KEY"))
    paypal_ok = bool(os.getenv("PAYPAL_CLIENT_ID") and os.getenv("PAYPAL_SECRET"))
    bp_count = len(app.blueprints)
    app.logger.info(
        "Payments config: Stripe=%s, PayPal=%s",
        "✅" if stripe_ok else "❌",
        "✅" if paypal_ok else "❌",
    )
    print(
        f"┌────────────────────────────────────────────┐\n"
        f"│  🌟 FundChamps Flask: Ready to Launch       │\n"
        f"│  ENV = {app.config.get('ENV','unknown'):<12}   DEBUG = {str(app.debug):<5}   │\n"
        f"│  Stripe={'ON ' if stripe_ok else 'OFF'}  PayPal={'ON ' if paypal_ok else 'OFF'}          │\n"
        f"│  Blueprints: {bp_count:<3}                         │\n"
        f"└────────────────────────────────────────────┘"
    )

    return app

