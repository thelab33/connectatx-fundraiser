# FundChamps — Shopify / Apple / Nike Aesthetic Pack (v1)

**What you get**
- `fc_shopify_overrides.css` – a clean, flat, monochrome-forward skin
- `shopify_overrides.js` – tiny helper to toggle the skin
- `_shopify_head_include.html` – drop this into `<head>` after your elite CSS
- `_shopify_body_include.html` – drop at the end of `<body>` to enable auto‑toggle

## Quick install
1. Unzip to your project root (keeps `static/css`, `static/js`, `templates/partials`).
2. In `base.html` (or your layout), after `fc_elite.css` include:
   ```jinja2
   {% include "partials/_shopify_head_include.html" ignore missing %}
   ```
3. Just before `</body>`, include:
   ```jinja2
   {% include "partials/_shopify_body_include.html" ignore missing %}
   ```
4. Turn it on by setting a data attribute on `<html>` (or call via JS):
   ```html
   <html lang="en" data-theme="dark" data-skin="shopify">
   ```
   or at runtime:
   ```js
   FCShop.skin('shopify');  // 'default' to turn off
   ```

### Notes
- This pack is **non-destructive**. It only overrides visuals when `data-skin="shopify"` is present.
- Works with your existing tokens/JS. No template rewrites necessary.
- Density: add `data-density="compact"` on `<html>` to tighten spacing further.
