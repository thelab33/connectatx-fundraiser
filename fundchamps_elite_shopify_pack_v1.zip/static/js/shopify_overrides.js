// FundChamps "Shopify" skin toggle
// Usage: include at end of <body>, then call FCShop.skin('shopify') or FCShop.skin('default')
(function(w,d){
  w.FCShop = w.FCShop || {};
  FCShop.skin = function(name){
    var root = d.documentElement;
    if(name === 'shopify'){ root.setAttribute('data-skin','shopify'); }
    else{ root.removeAttribute('data-skin'); }
    try{ localStorage.setItem('fc_skin', name||'default'); }catch{}
  };
  // auto-apply persisted choice
  try{
    var pref = localStorage.getItem('fc_skin');
    if(pref === 'shopify'){ d.documentElement.setAttribute('data-skin','shopify'); }
  }catch{}
})(window, document);
