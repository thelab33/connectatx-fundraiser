FundChamps Hotfix (no-duplicate sections)
=========================================

Files included:
- app/templates/base.html   (slots-only layout; no section includes)
- app/templates/index.html  (renders each section exactly once)

Install:
  unzip -o fundchamps_hotfix_minimal_base_index_v3.zip -d .
  # then restart your Flask app and hard refresh

Verify:
  grep -R "partials/tiers.html" -n app/templates   # should show ONLY index.html (and sponsor.html page)
  grep -n "include \"partials" app/templates/base.html  # should output nothing