# FundChamps Header Fix Kit (v3.0)

**What this is:** a drop‑in CSS/JS patch to make the refactored header render correctly even if older styles/scripts are still around or CSP blocks inline `<style>`/`<script>`.

## Files
- `static/css/header.fix.css` — full header styles + hardening overrides.
- `static/js/header.runtime.js` — CSP‑safe runtime (hamburger, share, progress, countdown, etc.).

## Install (Flask/Jinja)
1) Put these files under your app's `/static` path (keep the folders).
2) In `base.html` (or the template that renders the header), add **AFTER any older CSS**, ideally just before `</head>`:

```jinja2
{% set ver = ver|default(1759744311) %}
<link rel="stylesheet" href="{{ url_for('static', filename='css/header.fix.css') }}?v=1759744311">
```

3) Add the runtime **before `</body>`**:
```jinja2
<script src="{{ url_for('static', filename='js/header.runtime.js') }}?v=1759744311"></script>
```

> Using an external `<link>`/`<script src>` works even with strict CSPs that block inline CSS/JS without a nonce.

## Sanity Checks
- Open DevTools → **Network** tab → confirm `header.fix.css` and `header.runtime.js` load with 200 OK.
- DevTools → **Console** → you should see no CSP errors; a `fc:analytics` event will fire named `header_runtime_ready`.
- If you still see the big logo or stacked CTAs, your old CSS is overriding: ensure this link is **last**.

## Optional
- Cap header width while keeping rest fluid:
```css
.fc-hdr-grid{ max-width:1200px; }
```
