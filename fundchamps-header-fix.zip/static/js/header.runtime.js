// ===== FundChamps Header Runtime (v3.0) — CSP-safe, vanilla JS =====
// Put in static/js/header.runtime.js and include with <script src="..."></script>

(() => {
  'use strict';
  const $  = (s, r=document) => r.querySelector(s);
  const on = (el, ev, fn, opts) => el && el.addEventListener(ev, fn, opts);
  const mm = (q) => (window.matchMedia ? window.matchMedia(q) : { matches:false, addEventListener:()=>{} });
  const prefersReducedData = mm('(prefers-reduced-data: reduce)').matches;
  const analytics = (name, detail={}) => { try { window.dispatchEvent(new CustomEvent('fc:analytics', { detail:{ name, ...detail }})); } catch(_){} };

  function initTheme(){
    const KEY='fc-theme', btn = $('#theme-toggle');
    const apply = (t) => document.documentElement.setAttribute('data-theme', t);
    let saved=null; try { saved = localStorage.getItem(KEY); } catch(_){}
    apply(saved || (mm('(prefers-color-scheme: light)').matches ? 'light':'dark'));
    on(btn,'click',()=>{
      const next = (document.documentElement.getAttribute('data-theme')==='dark') ? 'light':'dark';
      apply(next); try { localStorage.setItem(KEY,next); } catch(_){}
      analytics('theme_toggled',{theme:next});
    },{passive:true});
  }
  function initShare(){
    const el = $('#hdr-share'); if (!el) return;
    on(el,'click', async ()=>{
      try{
        const payload = JSON.parse(el.getAttribute('data-share')||'{}');
        if (navigator.share && !prefersReducedData) await navigator.share(payload);
        else if (navigator.clipboard && location.protocol.startsWith('http')){
          await navigator.clipboard.writeText(payload.url || location.href);
          const prev = el.textContent; el.textContent='Copied'; setTimeout(()=>el.textContent=prev,1200);
        } else { window.prompt('Copy this link:', (payload.url||location.href)); }
        analytics('share_clicked');
      }catch(_){}
    },{passive:true});
  }
  function initMenu(){
    const burger = document.getElementById('menu-toggle') || document.querySelector('.fc-burger');
    const menu   = document.getElementById('fc-menu');
    if (!burger || !menu) return;
    const setOpen = (open)=>{
      menu.classList.toggle('is-open', open);
      burger.classList.toggle('is-active', open);
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (open){ const first = menu.querySelector('a,button'); first && first.focus({preventScroll:true}); }
    };
    on(burger,'click',()=> setOpen(!menu.classList.contains('is-open')), {passive:true});
    on(document,'click',(e)=>{
      if (!menu.classList.contains('is-open')) return;
      if (!e.target.closest('#fc-menu') && !e.target.closest('#menu-toggle') && !e.target.closest('.fc-burger')) setOpen(false);
    });
    on(document,'keydown',(e)=>{ if (e.key==='Escape') setOpen(false); });
    window.FundChampsHeader = Object.assign(window.FundChampsHeader||{}, { openMenu:()=>setOpen(true), closeMenu:()=>setOpen(false) });
  }
  function initDeadline(){
    const el = document.getElementById('hdr-deadline'); if (!el) return;
    const iso = el.getAttribute('data-countdown'); if (!iso) return;
    const end = new Date(iso); if (isNaN(end.getTime())) return;
    const tick = ()=>{
      const ms = Math.max(0, end - new Date());
      const days = Math.floor(ms/86400000), hrs = Math.floor((ms%86400000)/3600000);
      el.textContent = days>0 ? `${days}d ${hrs}h left` : (ms>0 ? 'Ends today' : 'Closed');
    };
    tick(); setInterval(tick, 3600000);
  }
  function initProgress(){
    const progress = document.getElementById('hdr-progress');
    const sticky   = document.getElementById('sticky-progress');
    const pctEl    = document.getElementById('hdr-percent');
    const setPct = (p)=>{
      const clamped = Math.max(0, Math.min(100, Number(p)||0));
      if (progress) progress.value = clamped;
      if (pctEl) pctEl.textContent = Math.round(clamped) + '%';
      if (sticky) sticky.style.width = clamped + '%';
    };
    if (progress){ setPct(progress.max ? (progress.value/progress.max)*100 : Number(progress.value)||0); }
    else if (sticky){ const w = parseFloat(sticky.style.width)||0; setPct(w); }
    window.FundChampsHeader = Object.assign(window.FundChampsHeader||{}, { setProgress: setPct });
  }
  function initDonateScroll(){
    const btn = document.getElementById('hdr-donate'); if (!btn) return;
    btn.addEventListener('click',(e)=>{
      const href = btn.getAttribute('href')||'';
      if (href.startsWith('#')){
        const target = document.getElementById(href.slice(1)) || document.querySelector('[data-donate]');
        if (target){ e.preventDefault(); target.scrollIntoView({behavior:'smooth', block:'start'}); }
      }
    },{passive:false});
  }
  function initStickyA11y(){
    const wrap = document.querySelector('.fc-sticky-donate') || document.querySelector('.sticky-donate'); if (!wrap) return;
    const mq = mm('(max-width: 860px)'); const sync = ()=> wrap.setAttribute('aria-hidden', mq.matches ? 'false' : 'true');
    sync(); mq.addEventListener && mq.addEventListener('change', sync);
  }
  function initHotkeys(){
    const isTyping = (e)=>{ const t=e.target; return t && (t.isContentEditable || /^(input|textarea|select)$/i.test(t.tagName)); };
    document.addEventListener('keydown',(e)=>{
      if (isTyping(e) || e.metaKey || e.ctrlKey || e.altKey) return;
      const k=(e.key||'').toLowerCase();
      if (k==='d'){ ( document.querySelector('[data-donate-cta]') || document.getElementById('hdr-donate') )?.focus(); }
      else if (k==='s'){ document.getElementById('hdr-share')?.click(); }
      else if (k==='m'){ document.querySelector('[data-monthly]')?.click(); }
    });
  }
  function initAnalytics(){
    document.addEventListener('click',(e)=>{
      const el = e.target.closest('[data-analytics]'); if (!el) return;
      try { window.dispatchEvent(new CustomEvent('fc:analytics', { detail:{ name: el.getAttribute('data-analytics')||'' }})); } catch(_){}
    },{passive:true});
  }
  function boot(){
    initTheme(); initShare(); initMenu(); initDeadline(); initProgress();
    initDonateScroll(); initStickyA11y(); initHotkeys(); initAnalytics();
    try { window.dispatchEvent(new CustomEvent('fc:analytics', { detail:{ name:'header_runtime_ready' }})); } catch(_){}
  }
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot, { once:true }); else boot();
})();
