// Starforge micro-interactions
(() => {
  // share buttons
  document.querySelectorAll('[data-analytics="cta:tiers:share"],[data-share]').forEach(btn => {
    btn.addEventListener('click', async () => {
      try{
        const data = JSON.parse(btn.getAttribute('data-share')||'{}');
        if (navigator.share) await navigator.share(data);
        else if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(data.url || location.href);
        window.fcTrack && fcTrack('share', data);
      }catch{}
    }, {passive:true});
  });

  // compact header on scroll
  const header = document.getElementById('site-header');
  let y0 = scrollY;
  addEventListener('scroll', () => {
    const y = scrollY;
    const shrink = y > 24 && y >= y0;
    header?.classList.toggle('is-shrunk', shrink);
    y0 = y;
  }, {passive:true});
})();
