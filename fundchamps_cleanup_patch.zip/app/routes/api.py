from __future__ import annotations

"""
FundChamps API (read-only surface)
- /api/docs  (Swagger UI)
- /api/status
- /api/stats
- /api/donors
- /api/impact-buckets
- /api/payments/config   (public boot info)
- /api/payments/readiness (diagnostic flags)
Write/payment endpoints live in app/blueprints/fc_payments.py
"""

from typing import Any, Dict, List, Optional
from flask import Blueprint, current_app
from flask_restx import Api, Resource, fields
from sqlalchemy import desc, func, text
from sqlalchemy import inspect as sa_inspect

from app.extensions import db

# Optional models (schema tolerant)
try:
    from app.models.campaign_goal import CampaignGoal  # type: ignore
except Exception:  # pragma: no cover
    CampaignGoal = None  # type: ignore

try:
    from app.models.donation import Donation  # type: ignore
except Exception:  # pragma: no cover
    Donation = None  # type: ignore

try:
    from app.models.sponsor import Sponsor  # type: ignore
except Exception:  # pragma: no cover
    Sponsor = None  # type: ignore

# Blueprint + RESTX API
api_bp = Blueprint("api", __name__, url_prefix="/api")
bp = api_bp  # alias if your registrar imports `bp`

api = Api(
    api_bp,
    version="1.0",
    title="FundChamps API",
    description="Public, read-only API for the FundChamps platform",
    doc="/docs",
)

# --- Swagger models
leaderboard_model = api.model(
    "Leaderboard",
    {"name": fields.String, "amount": fields.Float},
)
donor_model = api.model(
    "Donor",
    {"name": fields.String, "amount": fields.Float, "created_at": fields.String},
)
bucket_model = api.model(
    "ImpactBucket",
    {
        "id": fields.Integer,
        "slug": fields.String,
        "label": fields.String,
        "amount": fields.Float,
        "description": fields.String,
        "icon": fields.String,
    },
)
stats_model = api.model(
    "Stats",
    {
        "raised": fields.Float,
        "goal": fields.Float,
        "percent": fields.Float,
        "leaderboard": fields.List(fields.Nested(leaderboard_model)),
    },
)
status_model = api.model(
    "Status",
    {"status": fields.String, "message": fields.String, "version": fields.String, "docs": fields.String},
)
readiness_model = api.model(
    "PaymentsReadiness",
    {
        "stripe_ready": fields.Boolean,
        "paypal_ready": fields.Boolean,
        "stripe_public_key": fields.String,
        "paypal_env": fields.String,
        "paypal_client_id": fields.String,
    },
)
payments_cfg_model = api.model(
    "PaymentsConfig",
    {
        "stripe_public_key": fields.String,
        "paypal_env": fields.String,
        "paypal_client_id": fields.String,
    },
)

# --- Helpers
def _active_goal_amount() -> float:
    try:
        if CampaignGoal:
            q = db.session.query(CampaignGoal)
            if hasattr(CampaignGoal, "active"):
                q = q.filter(CampaignGoal.active.is_(True))
            elif hasattr(CampaignGoal, "is_active"):
                q = q.filter(CampaignGoal.is_active.is_(True))
            order_col = getattr(CampaignGoal, "updated_at", None) or getattr(CampaignGoal, "id", None)
            if order_col is not None:
                q = q.order_by(desc(order_col))
            row = q.first()
            if row:
                for col in ("goal_amount", "amount", "value"):
                    if hasattr(row, col):
                        return float(getattr(row, col) or 0.0)
    except Exception:
        current_app.logger.exception("Goal lookup failed; using fallback")
    try:
        cfg = current_app.config.get("TEAM_CONFIG", {}) or {}
        return float(cfg.get("fundraising_goal") or 10000)
    except Exception:
        return 10000.0

def _sum_sponsor_approved() -> float:
    if not Sponsor:
        return 0.0
    try:
        q = db.session.query(func.coalesce(func.sum(Sponsor.amount), 0.0))
        if hasattr(Sponsor, "deleted"):
            q = q.filter(Sponsor.deleted.is_(False))
        if hasattr(Sponsor, "status"):
            q = q.filter(Sponsor.status == "approved")
        return float(q.scalar() or 0.0)
    except Exception:
        return 0.0

def _sum_donations() -> float:
    if not Donation:
        return 0.0
    try:
        return float(db.session.query(func.coalesce(func.sum(Donation.amount), 0.0)).scalar() or 0.0)
    except Exception:
        return 0.0

def _recent_donations(limit: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if Donation:
        try:
            q = db.session.query(Donation)
            order_col = getattr(Donation, "created_at", None) or getattr(Donation, "id", None)
            if order_col is not None:
                q = q.order_by(desc(order_col))
            for d in q.limit(limit).all():
                name = None
                for k in ("display_name", "donor_name", "name"):
                    if hasattr(d, k) and getattr(d, k):
                        name = getattr(d, k)
                        break
                amount = 0.0
                for k in ("amount", "total", "value"):
                    if hasattr(d, k):
                        try:
                            amount = float(getattr(d, k) or 0.0)
                            break
                        except Exception:
                            pass
                created_at = ""
                for k in ("created_at", "created", "timestamp"):
                    if hasattr(d, k) and getattr(d, k):
                        created_at = str(getattr(d, k))
                        break
                out.append({"name": name or "Anonymous", "amount": amount, "created_at": created_at})
            return out
        except Exception:
            current_app.logger.exception("Recent donations query failed")
    # fallback to sponsors if Donation absent
    if Sponsor:
        try:
            q = db.session.query(Sponsor)
            col = getattr(Sponsor, "created_at", None) or getattr(Sponsor, "id", None)
            if hasattr(Sponsor, "deleted"):
                q = q.filter(Sponsor.deleted.is_(False))
            if hasattr(Sponsor, "status"):
                q = q.filter(Sponsor.status == "approved")
            if col is not None:
                q = q.order_by(desc(col))
            for s in q.limit(limit).all():
                out.append({"name": getattr(s, "name", "Sponsor"), "amount": float(getattr(s, "amount", 0.0) or 0.0), "created_at": str(getattr(s, "created_at", "") or "")})
        except Exception:
            pass
    return out

def _leaderboard(top_n: int) -> List[Dict[str, Any]]:
    if Sponsor:
        try:
            q = db.session.query(Sponsor)
            if hasattr(Sponsor, "deleted"):
                q = q.filter(Sponsor.deleted.is_(False))
            if hasattr(Sponsor, "status"):
                q = q.filter(Sponsor.status == "approved")
            q = q.order_by(desc(getattr(Sponsor, "amount", 0)))
            items = q.limit(top_n).all()
            return [{"name": getattr(s, "name", "Sponsor"), "amount": float(getattr(s, "amount", 0.0) or 0.0)} for s in items]
        except Exception:
            pass
    return []

# --- Endpoints
@api.route("/status")
class Status(Resource):
    @api.marshal_with(status_model)
    def get(self):
        return {"status": "ok", "message": "API live", "version": "1.0.0", "docs": "/api/docs"}

@api.route("/stats")
class StatsResource(Resource):
    @api.marshal_with(stats_model)
    def get(self):
        raised = _sum_donations() + _sum_sponsor_approved()
        goal = _active_goal_amount()
        percent = (raised / goal * 100.0) if goal else 0.0
        lb = _leaderboard(10)
        data = {"raised": float(raised), "goal": float(goal), "percent": round(percent, 2), "leaderboard": lb}
        return data, 200, {"Cache-Control": "public, max-age=10"}

@api.route("/donors")
class DonorsResource(Resource):
    @api.marshal_list_with(donor_model)
    def get(self):
        donors = _recent_donations(12)
        return donors, 200, {"Cache-Control": "public, max-age=15"}

@api.route("/impact-buckets")
class ImpactBuckets(Resource):
    @api.marshal_list_with(bucket_model)
    def get(self):
        try:
            insp = sa_inspect(db.engine)
            table = None
            for cand in ("impact_bucket", "impact_buckets"):
                if insp.has_table(cand):
                    table = cand
                    break
            if table:
                rows = db.session.execute(text(f"""
                    SELECT
                      id,
                      COALESCE(slug, 'bucket_' || id) AS slug,
                      COALESCE(label, 'Impact')       AS label,
                      COALESCE(amount, 0)             AS amount,
                      COALESCE(description, '')       AS description,
                      COALESCE(icon, '')              AS icon
                    FROM {table}
                    ORDER BY sort_order NULLS LAST, id
                """)).fetchall()
                return [dict(r._mapping) for r in rows], 200, {"Cache-Control": "public, max-age=60"}
        except Exception:
            current_app.logger.warning("impact-buckets: DB not available, using fallback", exc_info=True)
        fallback = [
            {"id": 1, "slug": "gear", "label": "Team Gear", "amount": 50, "description": "Covers a player’s practice kit", "icon": "shirt"},
            {"id": 2, "slug": "travel", "label": "Away Travel", "amount": 150, "description": "Bus + meal stipend for one away game", "icon": "bus"},
            {"id": 3, "slug": "scholar", "label": "Scholarships", "amount": 300, "description": "One season fee for a player in need", "icon": "award"},
        ]
        return fallback, 200, {"Cache-Control": "public, max-age=300"}

# Public payments boot info (read-only)
def _cfg(name: str, default=None):
    try:
        v = current_app.config.get(name)
        return v if v is not None else (default)
    except Exception:
        return default

def _paypal_env() -> str:
    v = _cfg("PAYPAL_ENV", "sandbox") or "sandbox"
    return str(v).lower()

@api.route("/payments/config")
class PaymentsConfig(Resource):
    @api.marshal_with(payments_cfg_model)
    def get(self):
        cid = (_cfg("PAYPAL_CLIENT_ID") or "")  # public
        return {
            "stripe_public_key": _cfg("STRIPE_PUBLIC_KEY") or _cfg("STRIPE_PUBLISHABLE_KEY") or "",
            "paypal_env": _paypal_env(),
            "paypal_client_id": cid,
        }

@api.route("/payments/readiness")
class PaymentsReadiness(Resource):
    @api.marshal_with(readiness_model)
    def get(self):
        cid = _cfg("PAYPAL_CLIENT_ID") or ""
        sec = _cfg("PAYPAL_SECRET") or _cfg("PAYPAL_CLIENT_SECRET") or ""
        return {
            "stripe_ready": bool(_cfg("STRIPE_SECRET_KEY")),
            "paypal_ready": bool(cid and sec),
            "stripe_public_key": _cfg("STRIPE_PUBLIC_KEY") or _cfg("STRIPE_PUBLISHABLE_KEY") or "",
            "paypal_env": _paypal_env(),
            "paypal_client_id": cid,
        }
