
# FundChamps UI Kit (Drop‑in)

A tiny, framework‑agnostic set of **tokens**, **components**, and **accessibility helpers** designed for fundraising pages (tiers, impact buckets, leaderboards).

- Dark‑first with automatic light mode via `prefers-color-scheme`
- Accessible progress bars, focus rings, and sticky mobile CTA
- Responsive typography using `clamp()`
- Works with any stack (vanilla, React, Tailwind, Next.js—just import the CSS)

## Quick Start
1. Include the CSS and JS (order matters):
```html
<link rel="stylesheet" href="styles/tokens.css">
<link rel="stylesheet" href="styles/components.css">
<script defer src="js/ux.js"></script>
```
2. Open `components/index.html` for a reference implementation.

## Rebrand in 30s
Edit `styles/tokens.css` under `:root`—especially `--brand-*` and `--text-*`.  
Or generate a palette from one color:
```bash
python scripts/generate_theme.py "#E4A800" > styles/brand.css
# then import brand.css after tokens.css
```

## Audit Contrast
```bash
python scripts/audit_contrast.py styles/tokens.css
# see styles/contrast_report.md
```

## Tailwind (optional)
Add to your `tailwind.config.js`:
```js
module.exports = { theme: {
  extend: {
    colors: {
      bg: "var(--bg)",
      surface: { 1: "var(--surface-1)", 2: "var(--surface-2)", 3: "var(--surface-3)" },
      brand: { 50:"var(--brand-50)",100:"var(--brand-100)",200:"var(--brand-200)",300:"var(--brand-300)",400:"var(--brand-400)",500:"var(--brand-500)"},
      text: { 1:"var(--text-1)",2:"var(--text-2)",3:"var(--text-3)" },
    },
    borderRadius: { xl: "var(--radius-xl)" }
  }
}};
```

## Components Included
- `.btn` + variations: `.btn-primary`, `.btn-secondary`, `.btn-ghost`, `.btn-danger`
- `.card`, `.badge`, `.kpi`
- `.progress` (with `role="progressbar"` + `.bar`)
- `.announcement`, `.grid`, `.sticky-cta`, `.focus-ring`

## License
MIT
