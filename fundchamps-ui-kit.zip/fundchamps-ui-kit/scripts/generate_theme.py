
"""
Generate a brand theme from a single HEX color.
Usage:
  python scripts/generate_theme.py "#E4A800" > styles/brand.css
Outputs CSS variables --brand-50..900 and --brand-contrast chosen for accessibility.
"""
import sys, colorsys

def clamp(x,a,b): return max(a, min(b,x))

def hex_to_rgb(h):
    h = h.strip().lstrip('#')
    if len(h)==3: h = ''.join([c*2 for c in h])
    return tuple(int(h[i:i+2],16) for i in (0,2,4))

def rgb_to_hex(r,g,b): return "#%02x%02x%02x" % (round(r),round(g),round(b))

def lighten(color, factor):
    r,g,b = [c/255 for c in hex_to_rgb(color)]
    import colorsys
    h,l,s = colorsys.rgb_to_hls(r,g,b)
    l = clamp(l + factor*(1-l), 0, 1)
    return rgb_to_hex(*[c*255 for c in colorsys.hls_to_rgb(h,l,s)])

def darken(color, factor):
    r,g,b = [c/255 for c in hex_to_rgb(color)]
    import colorsys
    h,l,s = colorsys.rgb_to_hls(r,g,b)
    l = clamp(l*(1-factor), 0, 1)
    return rgb_to_hex(*[c*255 for c in colorsys.hls_to_rgb(h,l,s)])

def rel_lum(rgb):
    def f(c):
        c = c/255.0
        return c/12.92 if c <= 0.03928*255 else ((c+0.055)/1.055)**2.4
    r,g,b = rgb
    return 0.2126*f(r)+0.7152*f(g)+0.0722*f(b)

def contrast(a,b):
    def to_rgb(h):
        h=h.strip().lstrip('#'); 
        if len(h)==3: h=''.join(c*2 for c in h)
        return tuple(int(h[i:i+2],16) for i in (0,2,4))
    L1 = rel_lum(to_rgb(a)); L2 = rel_lum(to_rgb(b))
    L1, L2 = max(L1,L2), min(L1,L2)
    return (L1+0.05)/(L2+0.05)

def main(hexcolor):
    base = hexcolor
    shades = {
        50:  lighten(base,.75),
        100: lighten(base,.6),
        200: lighten(base,.45),
        300: lighten(base,.3),
        400: lighten(base,.15),
        500: base,
        600: darken(base,.15),
        700: darken(base,.3),
        800: darken(base,.5),
        900: darken(base,.7),
    }
    white = "#ffffff"; black = "#111111"
    contrast_color = white if contrast(white, shades[500]) >= contrast(black, shades[500]) else black
    print(":root {")
    for k in [50,100,200,300,400,500,600,700,800,900]:
        print(f"  --brand-{k}: {shades[k]};")
    print(f"  --brand-contrast: {contrast_color};")
    print("}")
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scripts/generate_theme.py \"#E4A800\"")
        sys.exit(1)
    main(sys.argv[1])
