
"""
WCAG color contrast auditor for your CSS tokens.
Usage:
  python scripts/audit_contrast.py ../styles/tokens.css
Creates a "contrast_report.md" next to the CSS file.
"""
import sys, re, os, math, json
from pathlib import Path

def rel_lum(rgb):
    def f(c):
        c = c/255.0
        return c/12.92 if c <= 0.03928*255 else ((c+0.055)/1.055)**2.4
    r,g,b = rgb
    return 0.2126*f(r)+0.7152*f(g)+0.0722*f(b)

def hex_to_rgb(h):
    h = h.strip().lstrip('#')
    if len(h)==3: h = ''.join([c*2 for c in h])
    return tuple(int(h[i:i+2],16) for i in (0,2,4))

def contrast(a,b):
    L1 = rel_lum(hex_to_rgb(a))
    L2 = rel_lum(hex_to_rgb(b))
    L1, L2 = max(L1,L2), min(L1,L2)
    return (L1+0.05)/(L2+0.05)

def parse_vars(css):
    # crude parser for --name: #hex; pairs
    m = re.findall(r'--([\w-]+)\s*:\s*(#[0-9a-fA-F]{3,6})', css)
    return {k:v for k,v in m}

def rate(ratio):
    if ratio >= 7: return "AAA (7.0)"
    if ratio >= 4.5: return "AA (4.5)"
    if ratio >= 3: return "AA Large (3.0)"
    return "Fail"

def main(path):
    css = Path(path).read_text()
    vars = parse_vars(css)
    pairs = [
        ('text-1','bg'),
        ('text-2','bg'),
        ('text-3','bg'),
        ('brand-contrast','brand-500'),
        ('brand-contrast','brand-400'),
        ('text-1','surface-1'),
        ('text-1','surface-2'),
        ('text-1','surface-3'),
    ]
    lines = ["# Contrast Report\\n"]
    for a,b in pairs:
        if a in vars and b in vars:
            r = round(contrast(vars[a], vars[b]),2)
            lines.append(f"- {a} on {b}: **{r}** → {rate(r)}")
    # Find any variables that are too close (self-audit for outlines)
    def dist(h1,h2):
        a = hex_to_rgb(h1); b = hex_to_rgb(h2)
        return sum(abs(a[i]-b[i]) for i in range(3))/765
    crit = []
    for n in ('outline','surface-2'):
        if n in vars and 'bg' in vars:
            crit.append(f"- Distance bg ↔ {n}: {round(dist(vars['bg'], vars[n]),2)} (>= .08 recommended)")
    lines.append("\\n" + "\\n".join(crit))
    out = Path(path).with_name("contrast_report.md")
    out.write_text("\\n".join(lines))
    print(f"Wrote {out}")
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)
    main(sys.argv[1])
